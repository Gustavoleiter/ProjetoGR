namespace ProjetoGR.Models.Enuns
{
   
    public enum TipoUrgencia
    {
        Baixa,
        Média,
        Alta
    }
}