namespace ProjetoGR.Controllers
{
    public class FaculdadesController
    {
        
    }
}