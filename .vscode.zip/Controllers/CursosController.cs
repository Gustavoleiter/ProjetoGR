using ProjetoGR.Models;
using Microsoft.EntityFrameworkCore;
using System;
using ProjetoGR.Data;
using ProjetoGR.Models.Enuns;
using Microsoft.AspNetCore.Mvc;





namespace ProjetoGR.Controllers
{
    [ApiController]
    [Route("[Controller]")]
    public class CursosController : ControllerBase
    {
        
        private readonly DataContext _context;

        public CursosController(DataContext context)
        {
            _context = context;
        }
        
        
        
        
        
        [HttpGet("MostrarTodos")]
        public async Task<IActionResult> Get()
        {
            try
            {
                List<Curso> lista = await _context.Cursos.ToListAsync();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
    }
}
