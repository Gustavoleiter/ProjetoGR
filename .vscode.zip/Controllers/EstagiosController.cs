namespace ProjetoGR.Controllers
{
    public class EstagiosController
    {
        
    }
}